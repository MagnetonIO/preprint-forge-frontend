// src/lib/api.ts
import { PaperRequest, PaperResponse, PaperInfo } from "@/types/api"

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"

export async function generatePaper(request: PaperRequest): Promise<PaperResponse> {
  const response = await fetch(`${API_BASE}/papers/`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(request),
  })

  if (!response.ok) {
    const error = await response.json()
    throw new Error(error.detail || "Failed to generate paper")
  }

  return response.json()
}

export async function listPapers(): Promise<PaperInfo[]> {
  const response = await fetch(`${API_BASE}/papers/`)

  if (!response.ok) {
    const error = await response.json()
    throw new Error(error.detail || "Failed to fetch papers")
  }

  const data = await response.json()
  return data.papers
}
