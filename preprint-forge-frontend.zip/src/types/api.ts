// src/types/api.ts
export interface PaperInfo {
  name: string
  local_path: string
  has_md: boolean
  has_tex: boolean
  has_pdf: boolean
  github_url?: string
  github_status?: string
}

export interface PaperRequest {
  prompt: string
  setup_pages?: boolean
  post_social?: boolean
  create_markdown?: boolean
  create_latex?: boolean
  author?: string
  institution?: string
  department?: string
  email?: string
  date_str?: string
}

export interface PaperResponse {
  paper_name: string
  repo_url: string
  project_dir: string
}
