// src/components/papers/paper-list.tsx
import { PaperInfo } from "@/types/api"
import { ScrollArea } from "@/components/ui/scroll-area"
import { GithubIcon } from "lucide-react"

interface PaperListProps {
  papers: PaperInfo[]
  onPaperDeleted: () => void
}

export function PaperList({ papers = [], onPaperDeleted }: PaperListProps) {
  return (
    <div className="w-80 border-r bg-muted/10">
      <div className="p-4 font-semibold">Generated Papers ({papers.length})</div>
      <ScrollArea className="h-[calc(100vh-4rem)]">
        <div className="space-y-2 p-4">
          {papers.map((paper) => (
            <div
              key={paper.name}
              className="group rounded-lg border p-3 hover:bg-muted/50"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="font-medium truncate">{paper.name}</div>
                {paper.github_url && (
                  <a
                    href={paper.github_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="opacity-0 group-hover:opacity-100"
                  >
                    <GithubIcon className="h-4 w-4" />
                  </a>
                )}
              </div>
              <div className="text-sm text-muted-foreground">
                {paper.has_md ? "MD " : ""}
                {paper.has_tex ? "TEX " : ""}
                {paper.has_pdf ? "PDF" : ""}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}
