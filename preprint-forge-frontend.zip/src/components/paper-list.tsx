// src/components/paper-list.tsx
import { PaperInfo } from "@/types/api"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { Trash2Icon, GithubIcon, FileTextIcon, FileIcon } from "lucide-react"
import { deletePaper } from "@/lib/api"
import { useToast } from "@/components/ui/use-toast"

interface PaperListProps {
  papers: PaperInfo[]
  onPaperDeleted: (paperName: string) => void
}

export function PaperList({ papers, onPaperDeleted }: PaperListProps) {
  const { toast } = useToast()

  const handleDelete = async (paperName: string) => {
    try {
      await deletePaper(paperName)
      onPaperDeleted(paperName)
      toast({
        title: "Success",
        description: `Deleted paper: ${paperName}`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete paper",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="w-80 border-r bg-muted/10">
      <div className="p-4 font-semibold">Generated Papers ({papers.length})</div>
      <ScrollArea className="h-[calc(100vh-4rem)]">
        <div className="space-y-2 p-4">
          {papers.map((paper) => (
            <div
              key={paper.name}
              className="group rounded-lg border p-3 hover:bg-muted/50"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="font-medium truncate">{paper.name}</div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDelete(paper.name)}
                    className="opacity-0 group-hover:opacity-100 h-8 w-8"
                  >
                    <Trash2Icon className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                {paper.has_md && <FileTextIcon className="h-4 w-4" />}
                {paper.has_tex && <FileIcon className="h-4 w-4" />}
                {paper.github_url && (
                  <a
                    href={paper.github_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="ml-auto"
                  >
                    <GithubIcon className="h-4 w-4" />
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

// src/components/chat-interface.tsx
import { useState } from "react"
import { PaperResponse, PaperRequest } from "@/types/api"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useToast } from "@/components/ui/use-toast"
import { generatePaper } from "@/lib/api"

interface Message {
  role: "user" | "assistant"
  content: string
}

interface ChatInterfaceProps {
  onPaperGenerated: (paper: PaperResponse) => void
}

export function ChatInterface({ onPaperGenerated }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage = { role: "user" as const, content: input }
    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const paperRequest: PaperRequest = {
        prompt: input,
        create_markdown: true,
        create_latex: true,
      }

      const paper = await generatePaper(paperRequest)
      
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: `Successfully generated paper "${paper.paper_name}"! You can find it at ${paper.repo_url}`,
        },
      ])
      
      onPaperGenerated(paper)
      
      toast({
        title: "Success",
        description: "Paper generated successfully!",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to generate paper",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-1 flex-col">
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message, i) => (
            <div
              key={i}
              className={`flex ${
                message.role === "assistant" ? "justify-start" : "justify-end"
              }`}
            >
              <div
                className={`rounded-lg px-4 py-2 max-w-[80%] ${
                  message.role === "assistant"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted"
                }`}
              >
                {message.content}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      <form onSubmit={handleSubmit} className="border-t p-4">
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Enter your research topic or question..."
            disabled={isLoading}
          />
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Generating..." : "Generate"}
          </Button>
        </div>
      </form>
    </div>
  )
}
